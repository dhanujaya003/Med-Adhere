import React, { useEffect, useState } from 'react';
import { Copy, Plus, ShieldCheck, UserPlus, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import EmptyState from '@/components/EmptyState';
import PageHeader from '@/components/PageHeader';
import { useToast } from '@/components/ui/use-toast';
import useTodayDoses from '@/hooks/useTodayDoses';
import { upcomingRefills } from '@/lib/doses';
import { useSettings } from '@/lib/SettingsContext';
import { formatTime, refillInfo } from '@/lib/schedule';

const PERMISSIONS = ['schedule', 'adherence', 'refills', 'stock'];
const PERMISSION_LABELS = {
  schedule: 'caregivers.permSchedule',
  adherence: 'caregivers.permAdherence',
  refills: 'caregivers.permRefills',
  stock: 'caregivers.permStock',
};

const EMPTY_FORM = {
  caregiver_name: '',
  caregiver_email: '',
  relationship: '',
  permissions: ['schedule', 'adherence', 'refills'],
  notify_refills: true,
  notify_unconfirmed: true,
  consent: false,
};

export default function Caregivers() {
  const { t, settings, user } = useSettings();
  const { toast } = useToast();
  const { medications, doses } = useTodayDoses();
  const [grants, setGrants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);
  const [pendingRevoke, setPendingRevoke] = useState(null);

  const load = async () => {
    const page = await base44.entities.CaregiverAccess.list({ sort: '-created_date', limit: 100 });
    setGrants(page?.items || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const active = grants.filter((grant) => grant.status === 'active');
  const refills = upcomingRefills(medications, refillInfo);
  const overdue = doses.filter((dose) => !dose.status && Date.now() - dose.datetime.getTime() > 2 * 60 * 60 * 1000);

  const togglePermission = (permission) => {
    setForm((prev) => ({
      ...prev,
      permissions: prev.permissions.includes(permission)
        ? prev.permissions.filter((item) => item !== permission)
        : [...prev.permissions, permission],
    }));
  };

  const invite = async () => {
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.caregiver_email.trim())) {
      setError(t('caregivers.emailRequired')); return;
    }
    if (!form.consent) { setError(t('caregivers.consentRequired')); return; }
    if (form.permissions.length === 0) { setError(t('caregivers.permissions')); return; }
    setError(null); setSaving(true);
    try {
      await base44.entities.CaregiverAccess.create({
        caregiver_name: form.caregiver_name.trim(),
        caregiver_email: form.caregiver_email.trim().toLowerCase(),
        relationship: form.relationship.trim(),
        permissions: form.permissions,
        notify_refills: form.notify_refills,
        notify_unconfirmed: form.notify_unconfirmed,
        consent_given: true,
        consented_at: new Date().toISOString(),
        status: 'active',
        owner_name: user?.full_name || '',
      });
      setForm(EMPTY_FORM); setOpen(false); await load();
      toast({ title: t('caregivers.added') });
    } finally { setSaving(false); }
  };

  const revoke = async () => {
    if (!pendingRevoke) return;
    await base44.entities.CaregiverAccess.update(pendingRevoke.id, {
      status: 'revoked', revoked_at: new Date().toISOString(),
    });
    setPendingRevoke(null); await load();
  };

  const copyEmail = async (email) => {
    await navigator.clipboard?.writeText(email);
    toast({ title: t('common.copied') });
  };

  return (
    <div className="caregivers-page">
      <PageHeader title={t('caregivers.title')} subtitle={t('caregivers.subtitle')}
        action={<Button size="lg" onClick={() => setOpen(true)}>
          <UserPlus className="mr-2 h-5 w-5" aria-hidden="true" />{t('caregivers.invite')}
        </Button>} />

      <div className="space-y-5">
        <section className="flex gap-3 rounded-3xl border border-border bg-accent/40 p-4">
          <ShieldCheck className="mt-0.5 h-6 w-6 shrink-0 text-accent-foreground" aria-hidden="true" />
          <p className="text-base text-accent-foreground">{t('app.safety')}</p>
        </section>

        {loading ? <p className="text-base text-muted-foreground">{t('common.loading')}</p>
          : active.length === 0 ? <EmptyState icon={Users} title={t('caregivers.empty')} body={t('caregivers.consentHint')} />
          : active.map((grant) => (
            <article key={grant.id} className="rounded-3xl border border-border bg-card p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-heading text-lg font-bold">{grant.caregiver_name || grant.caregiver_email}</p>
                  <button type="button" onClick={() => copyEmail(grant.caregiver_email)}
                    className="mt-0.5 inline-flex items-center gap-1.5 text-sm text-muted-foreground underline">
                    <Copy className="h-3.5 w-3.5" aria-hidden="true" />{grant.caregiver_email}
                  </button>
                  <p className="mt-1 text-sm text-muted-foreground">
                    {grant.relationship ? `${grant.relationship} · ` : ''}{t('caregivers.sharedOn')}: {grant.consented_at ? new Date(grant.consented_at).toLocaleString() : '–'}
                  </p>
                </div>
                <Button variant="outline" size="lg" onClick={() => setPendingRevoke(grant)}>{t('caregivers.revoke')}</Button>
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                {(grant.permissions || []).map((permission) => (
                  <span key={permission} className="rounded-full bg-secondary px-2.5 py-1 text-sm font-semibold text-secondary-foreground">
                    {t(PERMISSION_LABELS[permission])}
                  </span>
                ))}
                {grant.notify_refills && <span className="rounded-full bg-accent px-2.5 py-1 text-sm font-semibold text-accent-foreground">{t('caregivers.notifyRefills')}</span>}
                {grant.notify_unconfirmed && <span className="rounded-full bg-accent px-2.5 py-1 text-sm font-semibold text-accent-foreground">{t('caregivers.notifyUnconfirmed')}</span>}
              </div>

              <div className="mt-4 rounded-2xl bg-secondary/60 p-3">
                <p className="text-sm font-bold uppercase tracking-wide text-muted-foreground">{t('caregivers.preview')}</p>
                {(grant.permissions || []).includes('schedule') && doses.length > 0 && (
                  <ul className="mt-2 space-y-1">{doses.slice(0, 4).map((dose) => (
                    <li key={dose.key} className="flex items-center justify-between gap-2 text-sm">
                      <span className="font-medium">{dose.medication.name}</span>
                      <span className="text-muted-foreground">{formatTime(dose.time, settings.language)}</span>
                    </li>
                  ))}</ul>
                )}
                {(grant.permissions || []).includes('refills') && refills.length > 0 && (
                  <p className="mt-2 text-sm font-semibold text-amber-900">{t('caregivers.previewRefill')}: {refills.map((row) => row.medication.name).join(', ')}</p>
                )}
                {(grant.permissions || []).includes('adherence') && grant.notify_unconfirmed && overdue.length > 0 && (
                  <p className="mt-2 text-sm font-semibold text-amber-900">{t('caregivers.previewUnconfirmed')}: {overdue.map((dose) => dose.medication.name).join(', ')}</p>
                )}
                {!(grant.permissions || []).length && <p className="mt-2 text-sm text-muted-foreground">{t('caregivers.noPreview')}</p>}
              </div>
              <p className="mt-3 text-sm text-muted-foreground">{t('caregivers.inviteHint')}</p>
            </article>
          ))}

        {grants.some((grant) => grant.status === 'revoked') && (
          <section className="rounded-3xl border border-border bg-card p-4">
            <h2 className="font-heading text-lg font-bold">{t('caregivers.revoked')}</h2>
            <p className="text-sm text-muted-foreground">{t('caregivers.revokeNote')}</p>
            <ul className="mt-3 space-y-2">{grants.filter((grant) => grant.status === 'revoked').map((grant) => (
              <li key={grant.id} className="flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-secondary px-3 py-2 text-sm">
                <span className="font-semibold">{grant.caregiver_name || grant.caregiver_email}</span>
                <span className="text-muted-foreground">{grant.revoked_at ? `${t('caregivers.revoked')} · ${new Date(grant.revoked_at).toLocaleDateString()}` : t('caregivers.revoked')}</span>
              </li>
            ))}</ul>
          </section>
        )}
      </div>

      <Dialog open={open} onOpenChange={(next) => { setOpen(next); if (!next) setError(null); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
          <DialogHeader><DialogTitle className="font-heading text-xl">{t('caregivers.invite')}</DialogTitle><DialogDescription>{t('caregivers.inviteHint')}</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div><Label htmlFor="cg-name">{t('caregivers.name')}</Label><Input id="cg-name" value={form.caregiver_name} onChange={(event) => setForm((prev) => ({ ...prev, caregiver_name: event.target.value }))} className="mt-1.5 h-12 text-base" /></div>
            <div><Label htmlFor="cg-email">{t('caregivers.email')}</Label><Input id="cg-email" type="email" value={form.caregiver_email} onChange={(event) => setForm((prev) => ({ ...prev, caregiver_email: event.target.value }))} className="mt-1.5 h-12 text-base" /></div>
            <div><Label htmlFor="cg-relationship">{t('caregivers.relationship')}</Label><Input id="cg-relationship" value={form.relationship} onChange={(event) => setForm((prev) => ({ ...prev, relationship: event.target.value }))} placeholder={t('caregivers.relationshipPh')} className="mt-1.5 h-12 text-base" /></div>
            <fieldset><legend className="font-semibold">{t('caregivers.permissions')}</legend><div className="mt-2 space-y-2">
              {PERMISSIONS.map((permission) => <label key={permission} htmlFor={`perm-${permission}`} className="flex items-center gap-3 rounded-2xl border border-border px-3 py-3">
                <Checkbox id={`perm-${permission}`} checked={form.permissions.includes(permission)} onCheckedChange={() => togglePermission(permission)} />
                <span className="text-base font-medium">{t(PERMISSION_LABELS[permission])}</span>
              </label>)}
            </div></fieldset>
            <fieldset><legend className="font-semibold">{t('caregivers.alerts')}</legend><div className="mt-2 space-y-2">
              <label htmlFor="notify-refills" className="flex items-center gap-3 rounded-2xl border border-border px-3 py-3"><Checkbox id="notify-refills" checked={form.notify_refills} onCheckedChange={(value) => setForm((prev) => ({ ...prev, notify_refills: Boolean(value) }))} /><span className="text-base font-medium">{t('caregivers.notifyRefills')}</span></label>
              <label htmlFor="notify-unconfirmed" className="flex items-center gap-3 rounded-2xl border border-border px-3 py-3"><Checkbox id="notify-unconfirmed" checked={form.notify_unconfirmed} onCheckedChange={(value) => setForm((prev) => ({ ...prev, notify_unconfirmed: Boolean(value) }))} /><span className="text-base font-medium">{t('caregivers.notifyUnconfirmed')}</span></label>
            </div></fieldset>
            <label htmlFor="cg-consent" className="flex items-start gap-3 rounded-2xl border-2 border-primary/40 bg-primary/5 px-3 py-3">
              <Checkbox id="cg-consent" checked={form.consent} onCheckedChange={(value) => setForm((prev) => ({ ...prev, consent: Boolean(value) }))} />
              <span className="text-base font-medium">{t('caregivers.consentLabel')}<span className="mt-1 block text-sm text-muted-foreground">{t('caregivers.consentHint')}</span></span>
            </label>
            {error && <p className="rounded-2xl bg-rose-50 px-3 py-2 text-base font-semibold text-rose-800">{error}</p>}
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>{t('common.cancel')}</Button><Button onClick={invite} disabled={saving}><Plus className="mr-2 h-5 w-5" aria-hidden="true" />{saving ? t('common.saving') : t('caregivers.invite')}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={Boolean(pendingRevoke)} onOpenChange={(next) => !next && setPendingRevoke(null)}>
        <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>{t('caregivers.revokeTitle')}</AlertDialogTitle><AlertDialogDescription>{t('caregivers.revokeBody')}</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>{t('common.cancel')}</AlertDialogCancel><AlertDialogAction onClick={revoke}>{t('caregivers.revoke')}</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
