import React from 'react';
import { createRoot } from 'react-dom/client';
import Caregivers from './Caregivers.jsx';
import './caregivers.css';

// This entry point expects the original project's providers (settings, toast,
// routing, and Base44 client) to be configured at the application root.
// Import Caregivers into that existing root rather than running this file alone.
function Main() {
  return <Caregivers />;
}

createRoot(document.getElementById('root')).render(<Main />);
